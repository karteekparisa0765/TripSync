import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useOutletContext } from 'react-router-dom';
import {
  AlertCircle,
  CalendarDays,
  CheckCheck,
  CircleDollarSign,
  ImagePlus,
  ListPlus,
  MapPin,
  MessageCircle,
  Paperclip,
  Plus,
  RefreshCw,
  Route,
  Send,
  Smile,
  Sparkles,
  Users,
  WalletCards,
} from 'lucide-react';
import axiosInstance from '../../api/axiosInstance';
import { useAuth } from '../../context/AuthContext';
import { Card, PrimaryButton, SecondaryButton } from '../../components/ui';
import { formatDateRange, money } from '../../utils/format';
import { getEntityId } from '../../utils/ids';

const EMOJIS = ['😀', '👍', '🎉', '📍', '💸', '✈️'];

const initials = (name = 'Member') =>
  name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join('') || 'M';

const relativeTime = (value) => {
  const seconds = Math.max(0, Math.floor((Date.now() - new Date(value).getTime()) / 1000));
  if (seconds < 45) return 'just now';
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  if (seconds < 604800) return `${Math.floor(seconds / 86400)}d ago`;
  return new Date(value).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
};

const friendlyChatError = (err) => {
  const message = err.response?.data?.message || 'Failed to load messages';
  if (err.response?.status === 404 && message === 'Route not found') {
    return 'Chat API is not active. Restart the backend server to load the new chat routes.';
  }
  return message;
};

const systemIcon = {
  expense: CircleDollarSign,
  member: Users,
  itinerary: Route,
  settlement: CheckCheck,
  trip: Sparkles,
};

const TripChat = () => {
  const workspace = useOutletContext();
  const { id, trip, expenses, itinerary, settlement, budget } = workspace;
  const { user } = useAuth();
  const [messages, setMessages] = useState([]);
  const [draft, setDraft] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState('');
  const [emojiOpen, setEmojiOpen] = useState(false);
  const [attachmentName, setAttachmentName] = useState('');
  const scrollRef = useRef(null);
  const composerRef = useRef(null);
  const fileInputRef = useRef(null);
  const currentUserId = getEntityId(user);

  const fetchMessages = async ({ silent = false } = {}) => {
    if (!silent) setLoading(true);
    setError('');
    try {
      const { data } = await axiosInstance.get(`/trips/${id}/chat`);
      setMessages(data.messages || []);
    } catch (err) {
      setError(friendlyChatError(err));
    } finally {
      if (!silent) setLoading(false);
    }
  };

  useEffect(() => {
    fetchMessages();
    const interval = window.setInterval(() => fetchMessages({ silent: true }), 8000);
    return () => window.clearInterval(interval);
  }, [id]);

  const systemEvents = useMemo(() => {
    const events = [];

    if (trip.createdAt) {
      events.push({
        id: 'system-trip-created',
        kind: 'system',
        systemType: 'trip',
        createdAt: trip.createdAt,
        message: `${trip.name} group was created`,
      });
      events.push({
        id: 'system-members-joined',
        kind: 'system',
        systemType: 'member',
        createdAt: trip.createdAt,
        message: `${trip.members.length} member${trip.members.length !== 1 ? 's' : ''} joined the trip`,
      });
    }

    expenses.slice(0, 5).forEach((expense) => {
      events.push({
        id: `system-expense-${expense.id}`,
        kind: 'system',
        systemType: 'expense',
        createdAt: expense.createdAt || expense.date,
        message: `${expense.paidBy?.name || 'A member'} added ${expense.description} for ${money(expense.amount)}`,
      });
    });

    if (itinerary?.generatedAt) {
      events.push({
        id: 'system-itinerary',
        kind: 'system',
        systemType: 'itinerary',
        createdAt: itinerary.generatedAt,
        message: 'The trip itinerary was updated',
      });
    }

    if (expenses.length > 0 && settlement?.transactions?.length === 0) {
      events.push({
        id: 'system-settlement',
        kind: 'system',
        systemType: 'settlement',
        createdAt: expenses[0]?.date || trip.createdAt,
        message: 'All trip balances are settled',
      });
    }

    return events;
  }, [expenses, itinerary, settlement, trip]);

  const timeline = useMemo(
    () =>
      [
        ...systemEvents,
        ...messages.map((message) => ({ ...message, kind: message.kind || 'message' })),
      ].sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt)),
    [messages, systemEvents]
  );

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: loading ? 'auto' : 'smooth' });
  }, [loading, timeline.length]);

  const sendMessage = async (event) => {
    event.preventDefault();
    const content = [attachmentName ? `[Photo: ${attachmentName}]` : '', draft.trim()]
      .filter(Boolean)
      .join('\n');
    if (!content) return;

    setSending(true);
    setError('');
    try {
      const { data } = await axiosInstance.post(`/trips/${id}/chat`, { message: content });
      setMessages((current) => [...current, data.message]);
      setDraft('');
      setAttachmentName('');
      setEmojiOpen(false);
    } catch (err) {
      setError(friendlyChatError(err));
    } finally {
      setSending(false);
    }
  };

  const handleKeyDown = (event) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      event.currentTarget.form?.requestSubmit();
    }
  };

  const insertShareText = (text) => {
    setDraft((current) => (current ? `${current}\n${text}` : text));
    window.setTimeout(() => composerRef.current?.focus(), 0);
  };

  const handleAttachment = (event) => {
    const file = event.target.files?.[0];
    if (file) setAttachmentName(file.name);
    event.target.value = '';
  };

  return (
    <div className="-mt-2">
      <Card className="flex h-[calc(100vh-7rem)] min-h-[700px] overflow-hidden">
        <section className="flex min-w-0 flex-1 flex-col xl:w-3/4">
          <header className="sticky top-0 z-10 border-b border-gray-200 bg-white/95 px-5 py-4 backdrop-blur dark:border-gray-800 dark:bg-gray-900/95">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
              <div className="min-w-0">
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-indigo-600 text-white">
                    <MessageCircle className="h-5 w-5" />
                  </div>
                  <div className="min-w-0">
                    <h1 className="truncate text-lg font-bold text-gray-950 dark:text-gray-50">{trip.name}</h1>
                    <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-gray-500 dark:text-gray-400">
                      <span className="flex items-center gap-1"><Users className="h-3.5 w-3.5" /> {trip.members.length} members</span>
                      <span className="flex items-center gap-1"><WalletCards className="h-3.5 w-3.5" /> {money(budget.spent)} spent</span>
                      <span className="flex items-center gap-1"><CalendarDays className="h-3.5 w-3.5" /> {formatDateRange(trip.startDate, trip.endDate)}</span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                <Link to="../expenses"><SecondaryButton><Plus className="h-4 w-4" /> Expense</SecondaryButton></Link>
                <Link to="../places"><SecondaryButton><MapPin className="h-4 w-4" /> Place</SecondaryButton></Link>
                <Link to="../itinerary"><PrimaryButton><Route className="h-4 w-4" /> Plan</PrimaryButton></Link>
              </div>
            </div>
          </header>

          {error && (
            <div className="border-b border-amber-200 bg-amber-50 px-5 py-3 text-sm text-amber-800 dark:border-amber-900 dark:bg-amber-950 dark:text-amber-200">
              <div className="flex items-center gap-2">
                <AlertCircle className="h-4 w-4 shrink-0" />
                <span className="flex-1">{error}</span>
                <button onClick={() => fetchMessages()} className="rounded-md p-1 hover:bg-amber-100 dark:hover:bg-amber-900" title="Retry">
                  <RefreshCw className="h-4 w-4" />
                </button>
              </div>
            </div>
          )}

          <div className="flex-1 overflow-y-auto bg-slate-50 px-4 py-6 dark:bg-gray-950 sm:px-6">
            {loading ? (
              <div className="space-y-6">
                {[0, 1, 2, 3].map((item) => (
                  <div key={item} className={`flex gap-3 ${item % 2 ? 'flex-row-reverse' : ''}`}>
                    <div className="h-9 w-9 animate-pulse rounded-full bg-gray-200 dark:bg-gray-800" />
                    <div className={`space-y-2 ${item % 2 ? 'items-end' : ''}`}>
                      <div className="h-3 w-24 animate-pulse rounded bg-gray-200 dark:bg-gray-800" />
                      <div className="h-16 w-64 animate-pulse rounded-2xl bg-gray-200 dark:bg-gray-800" />
                    </div>
                  </div>
                ))}
              </div>
            ) : timeline.length === 0 ? (
              <div className="flex h-full items-center justify-center">
                <div className="max-w-sm text-center">
                  <div className="relative mx-auto mb-5 h-24 w-36">
                    <div className="absolute left-0 top-5 h-14 w-20 rounded-2xl rounded-bl-sm bg-indigo-100 dark:bg-indigo-950" />
                    <div className="absolute bottom-0 right-0 h-16 w-24 rounded-2xl rounded-br-sm bg-sky-100 dark:bg-sky-950" />
                    <MessageCircle className="absolute left-1/2 top-1/2 h-9 w-9 -translate-x-1/2 -translate-y-1/2 text-indigo-600 dark:text-indigo-300" />
                  </div>
                  <h2 className="text-lg font-semibold text-gray-950 dark:text-gray-50">Start the trip conversation</h2>
                  <p className="mt-2 text-sm leading-6 text-gray-500 dark:text-gray-400">
                    Share plans, payment reminders, places, photos, and itinerary updates with the group.
                  </p>
                </div>
              </div>
            ) : (
              <div className="space-y-1">
                {timeline.map((item, index) => {
                  if (item.kind === 'system') {
                    const Icon = systemIcon[item.systemType] || Sparkles;
                    return (
                      <div key={item.id} className="flex justify-center py-4">
                        <div className="flex max-w-xl items-center gap-2 rounded-full border border-gray-200 bg-white px-4 py-2 text-xs text-gray-600 shadow-sm dark:border-gray-800 dark:bg-gray-900 dark:text-gray-300">
                          <Icon className="h-3.5 w-3.5 text-indigo-600 dark:text-indigo-300" />
                          <span>{item.message}</span>
                          <span className="text-gray-400">{relativeTime(item.createdAt)}</span>
                        </div>
                      </div>
                    );
                  }

                  const senderId = getEntityId(item.sender);
                  const mine = senderId === currentUserId;
                  const previous = timeline[index - 1];
                  const grouped =
                    previous?.kind === 'message' &&
                    getEntityId(previous.sender) === senderId &&
                    new Date(item.createdAt) - new Date(previous.createdAt) < 5 * 60 * 1000;
                  const senderName = mine ? 'You' : item.sender?.name || 'Member';

                  return (
                    <div
                      key={item.id}
                      className={`group flex gap-3 px-1 transition hover:bg-gray-100/70 dark:hover:bg-gray-900/60 ${
                        mine ? 'flex-row-reverse' : ''
                      } ${grouped ? 'py-1' : 'pb-1 pt-5'}`}
                    >
                      <div className="w-9 shrink-0">
                        {!grouped && (
                          <div className={`flex h-9 w-9 items-center justify-center rounded-full text-xs font-bold ${
                            mine ? 'bg-indigo-600 text-white' : 'bg-sky-100 text-sky-700 dark:bg-sky-950 dark:text-sky-200'
                          }`}>
                            {initials(senderName)}
                          </div>
                        )}
                      </div>
                      <div className={`max-w-[78%] ${mine ? 'items-end' : 'items-start'} flex flex-col`}>
                        {!grouped && (
                          <div className={`mb-1 flex items-center gap-2 ${mine ? 'flex-row-reverse' : ''}`}>
                            <span className="text-xs font-semibold text-gray-700 dark:text-gray-200">{senderName}</span>
                            <span className="text-[11px] text-gray-400">{relativeTime(item.createdAt)}</span>
                          </div>
                        )}
                        <div className={`rounded-2xl px-4 py-2.5 text-sm leading-6 shadow-sm transition group-hover:shadow-md ${
                          mine
                            ? 'rounded-tr-md bg-indigo-600 text-white'
                            : 'rounded-tl-md border border-gray-200 bg-white text-gray-900 dark:border-gray-800 dark:bg-gray-900 dark:text-gray-100'
                        }`}>
                          <p className="whitespace-pre-wrap">{item.message}</p>
                        </div>
                        {mine && (
                          <span className="mt-1 flex items-center gap-1 text-[10px] text-gray-400">
                            <CheckCheck className="h-3 w-3 text-indigo-500" /> Delivered
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
                <div ref={scrollRef} />
              </div>
            )}
          </div>

          <footer className="border-t border-gray-200 bg-white px-4 py-3 dark:border-gray-800 dark:bg-gray-900">
            <div className="mb-3 flex gap-2 overflow-x-auto pb-1">
              <button onClick={() => insertShareText('Shared expense: ')} className="inline-flex shrink-0 items-center gap-2 rounded-full bg-gray-100 px-3 py-1.5 text-xs font-medium text-gray-700 transition hover:bg-indigo-100 hover:text-indigo-700 dark:bg-gray-800 dark:text-gray-200 dark:hover:bg-indigo-950">
                <CircleDollarSign className="h-3.5 w-3.5" /> Share Expense
              </button>
              <button onClick={() => insertShareText('Shared place: ')} className="inline-flex shrink-0 items-center gap-2 rounded-full bg-gray-100 px-3 py-1.5 text-xs font-medium text-gray-700 transition hover:bg-indigo-100 hover:text-indigo-700 dark:bg-gray-800 dark:text-gray-200 dark:hover:bg-indigo-950">
                <MapPin className="h-3.5 w-3.5" /> Share Place
              </button>
              <button onClick={() => insertShareText('Shared itinerary update: ')} className="inline-flex shrink-0 items-center gap-2 rounded-full bg-gray-100 px-3 py-1.5 text-xs font-medium text-gray-700 transition hover:bg-indigo-100 hover:text-indigo-700 dark:bg-gray-800 dark:text-gray-200 dark:hover:bg-indigo-950">
                <ListPlus className="h-3.5 w-3.5" /> Share Itinerary
              </button>
              <button onClick={() => fileInputRef.current?.click()} className="inline-flex shrink-0 items-center gap-2 rounded-full bg-gray-100 px-3 py-1.5 text-xs font-medium text-gray-700 transition hover:bg-indigo-100 hover:text-indigo-700 dark:bg-gray-800 dark:text-gray-200 dark:hover:bg-indigo-950">
                <ImagePlus className="h-3.5 w-3.5" /> Share Photo
              </button>
            </div>

            {attachmentName && (
              <div className="mb-2 inline-flex items-center gap-2 rounded-md bg-indigo-50 px-3 py-1.5 text-xs text-indigo-700 dark:bg-indigo-950 dark:text-indigo-200">
                <ImagePlus className="h-3.5 w-3.5" />
                {attachmentName}
                <button onClick={() => setAttachmentName('')} className="font-bold" aria-label="Remove attachment">×</button>
              </div>
            )}

            <form onSubmit={sendMessage} className="relative">
              {emojiOpen && (
                <div className="absolute bottom-full left-10 z-20 mb-2 flex gap-1 rounded-lg border border-gray-200 bg-white p-2 shadow-xl dark:border-gray-800 dark:bg-gray-900">
                  {EMOJIS.map((emoji) => (
                    <button key={emoji} type="button" onClick={() => { setDraft((value) => value + emoji); setEmojiOpen(false); }} className="rounded-md p-2 text-lg hover:bg-gray-100 dark:hover:bg-gray-800">
                      {emoji}
                    </button>
                  ))}
                </div>
              )}
              <div className="flex items-end gap-2 rounded-2xl border border-gray-300 bg-gray-50 p-2 focus-within:border-indigo-500 focus-within:ring-2 focus-within:ring-indigo-500/20 dark:border-gray-700 dark:bg-gray-950">
                <button type="button" onClick={() => fileInputRef.current?.click()} className="rounded-lg p-2 text-gray-500 transition hover:bg-gray-200 hover:text-gray-900 dark:hover:bg-gray-800 dark:hover:text-gray-100" title="Attach photo">
                  <Paperclip className="h-5 w-5" />
                </button>
                <button type="button" onClick={() => setEmojiOpen((value) => !value)} className="rounded-lg p-2 text-gray-500 transition hover:bg-gray-200 hover:text-gray-900 dark:hover:bg-gray-800 dark:hover:text-gray-100" title="Add emoji">
                  <Smile className="h-5 w-5" />
                </button>
                <textarea
                  ref={composerRef}
                  value={draft}
                  onChange={(event) => setDraft(event.target.value)}
                  onKeyDown={handleKeyDown}
                  rows="1"
                  maxLength={1000}
                  placeholder="Message the group..."
                  className="max-h-32 min-h-10 flex-1 resize-none border-0 bg-transparent px-1 py-2 text-sm outline-none placeholder:text-gray-400"
                />
                <div className="hidden pb-2 text-[10px] text-gray-400 sm:block">{draft.length}/1000</div>
                <button
                  type="submit"
                  disabled={sending || (!draft.trim() && !attachmentName)}
                  className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-indigo-600 text-white shadow-sm transition hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-40"
                  title="Send message"
                >
                  <Send className="h-4 w-4" />
                </button>
              </div>
              <div className="mt-1 flex h-4 items-center justify-between px-2 text-[11px] text-gray-400">
                <span>{draft.trim() ? 'You are typing...' : 'Press Enter to send · Shift+Enter for a new line'}</span>
                <span className="sm:hidden">{draft.length}/1000</span>
              </div>
              <input ref={fileInputRef} type="file" accept="image/*" onChange={handleAttachment} className="hidden" />
            </form>
          </footer>
        </section>

        <aside className="hidden w-1/4 min-w-72 border-l border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900 xl:flex xl:flex-col">
          <div className="border-b border-gray-200 px-5 py-4 dark:border-gray-800">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="font-semibold text-gray-950 dark:text-gray-50">Members</h2>
                <p className="mt-0.5 text-xs text-gray-500 dark:text-gray-400">{trip.members.length} people in this trip</p>
              </div>
              <Link to="../members" className="flex h-9 w-9 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600 transition hover:bg-indigo-100 dark:bg-indigo-950 dark:text-indigo-300" title="Invite member">
                <Plus className="h-4 w-4" />
              </Link>
            </div>
          </div>
          <div className="flex-1 overflow-y-auto p-4">
            <p className="mb-3 px-1 text-xs font-semibold uppercase text-gray-400">Online — 1</p>
            {trip.members
              .filter((member) => getEntityId(member) === currentUserId)
              .map((member) => (
                <MemberRow key={getEntityId(member)} member={member} online role={getEntityId(member) === getEntityId(trip.createdBy) ? 'Owner' : 'Member'} />
              ))}

            <p className="mb-3 mt-6 px-1 text-xs font-semibold uppercase text-gray-400">
              Offline — {Math.max(0, trip.members.length - 1)}
            </p>
            <div className="space-y-1">
              {trip.members
                .filter((member) => getEntityId(member) !== currentUserId)
                .map((member) => (
                  <MemberRow key={getEntityId(member)} member={member} role={getEntityId(member) === getEntityId(trip.createdBy) ? 'Owner' : 'Member'} />
                ))}
            </div>
          </div>
          <div className="border-t border-gray-200 p-4 dark:border-gray-800">
            <Link to="../members">
              <PrimaryButton className="w-full"><Plus className="h-4 w-4" /> Invite Member</PrimaryButton>
            </Link>
          </div>
        </aside>
      </Card>
    </div>
  );
};

const MemberRow = ({ member, online = false, role }) => (
  <div className="flex items-center gap-3 rounded-lg px-2 py-2.5 transition hover:bg-gray-100 dark:hover:bg-gray-800">
    <div className="relative">
      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-indigo-100 text-xs font-bold text-indigo-700 dark:bg-indigo-950 dark:text-indigo-200">
        {initials(member.name)}
      </div>
      <span className={`absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-white dark:border-gray-900 ${online ? 'bg-emerald-500' : 'bg-gray-400'}`} />
    </div>
    <div className="min-w-0 flex-1">
      <p className="truncate text-sm font-medium text-gray-950 dark:text-gray-50">{member.name}</p>
      <p className="truncate text-xs text-gray-500 dark:text-gray-400">{member.email}</p>
    </div>
    <span className={`rounded-md px-2 py-1 text-[10px] font-semibold ${
      role === 'Owner'
        ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-200'
        : 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300'
    }`}>
      {role}
    </span>
  </div>
);

export default TripChat;
